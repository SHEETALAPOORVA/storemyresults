# STORE MY RESULTS
Storemyresults is a user-friendly website which can resolve the problem of Complex Sophisticated website design. User can easily add, delete marks according to respective semesters and download the PDF form of the Data. The Data are stored and secured
# OVERVIEW OF THE PROJECT
This project is based on Web Development And its Applications. The main objective
of this project is to learn the implementation of Front-end Languages Like HTML,
CSS, JS, Bootstrap. Back-end PHP using server XAAMP and how to retrieve and
manage Data from MySQL Database.
#
Engineering Students Nowadays do not have the habit of remembering their marks of the previous semester, this can actually cause a huge problem to students in their final year of Engineering in order to solve this, we here at storemyresults.com provide a platform to students/Graduates to store their results of the previous or current semester thereby making it comfortable to access results and marks as accessible whenever required.
# WHY STORE MY RESULTS
As students complete each semester, they tend to forget marks of previous semesters. Hence it
might become tougher for students whenever the situation comes where they have to get their or
remember previous semesters marks. Hence, we developed a User-friendly website to store and
retrieve each semester marks.
The User has to Register themselves with the required details asked. Later the user can login.
Once the user login user will be redirected to the Homepage. In homepage Each semester will be
displayed. 
#
The user has to select the semester which user have to Store the marks in. Once the
user enters the particular semester web page, he/she can enter the Subject Code, Subject Name
and Marks of the Particular subject. The data will be displayed in the Result View. If the user
wants to delete the Data, user can use the Delete button adjacent to the Particular Data Row.
Once All the Details are added user can Download the PDF for future Reference, which
becomes more useful for the students. Once user enters all the required marks in respective
semester user can Logout.
#
The Data are well secured allowing only distinct Email-IDs. The Data are stored in MySQL
Database, where data are stored and retrieved when required as per the operations.
This makes the project user-friendly and efficient to use.
# TOOLS USED
•Software Requirements
#
• Visual Studio Code 2021
#
• Google Chrome
#
• Front-end: HTML, CSS, JavaScript, Bootstrap
#
• Back-end: PHP
#
• Server: XAAMP
#
• Database: MySQL
#
• Windows 10
